{
  "id": "posts",
  "name": "Post's",
  "description": "Sistema de Gerenciamento de Posts.",
  "version": "1.0.0",
  "provider": "Modules\\Posts\\PostsServiceProvider",
  "routes": [
    "Routes/web.php",
    "Routes/api.php"
  ],
  "migrations": [
    "Database/Migrations"
  ],
  "views": [
    "Resources/views"
  ],
  "assets": [
    "Resources/assets"
  ],
  "install": "install.php",
  "update": "update.php",
  "uninstall": "jninstall.php",
  "dependencies": {
    "core": ">=1.0.0"
  }
}